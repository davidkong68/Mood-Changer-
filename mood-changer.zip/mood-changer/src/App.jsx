

import{ useState } from 'react';   /*useState it lets your app remember something -- like the current emoji.*/
import './App.css'; /* in html it use link rel ='stylesheet' but react it use import keyword */  /* ./means look for the file in the current folder(my-mood-app).*/



function App(){
    const[mood, setMood] =useState("😊")

    return(
        <div className="container">
            <h1>How are you feeling today?</h1>
            <div className = "emoji">{mood}</div>
            <div className = "buttons">

                <button onClick={() => setMood("😄")}>Happy</button>
                <button onClick={() => setMood("😅")}>My bad</button>
                <button onClick={() => setMood("😡")}>Angry</button>
                <button onClick={() => setMood("😴")}>Sleepy</button>
            </div>

        </div>
    )


}

export default App;



/*Variables and Hooks → Use camelCase (no capital at the beginning) 

Camel case use for variable, functions,state hooks, props  */


/* All component word need to be capital letter. */

/* React's reserve word is class*/