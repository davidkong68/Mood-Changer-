import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './App.css';

ReactDOM.createRoot(document.getElementById('root')).render(      
  <React.StrictMode>
    <App />
  </React.StrictMode>
);


/*Take the App.jsx and put it inside the empty box(index.html) this shows on the webpage. In simple words  root = box, app = shoes, render() = the action of put the shows into the box.
this display something on the page*/ 